import torch
from torch import Tensor, Size
from typing import Union
from .. import _C

def BFPquant(
        src: Tensor,
        exp: Tensor,
        emin: float,
        emax: float,
        max_number: float,
        mbit: float,
        stochastic: bool
        ) -> torch.Tensor:
    
    if src.dtype != torch.float32:
        src = src.type(torch.float32)

    if exp.dtype != torch.float32:
        exp = exp.type(torch.float32)

    dist_type = src.dtype

    res = _C.bfp_quant(src, exp, emin, emax, max_number, mbit, stochastic)
    return res.to(dist_type)